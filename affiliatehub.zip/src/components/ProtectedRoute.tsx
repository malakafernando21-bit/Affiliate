import React from 'react';
import { useAuth } from '../lib/auth';
import { Navigate, Outlet } from 'react-router';

export const ProtectedRoute = ({ allowedRoles }: { allowedRoles?: string[] }) => {
  const { user, userData, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && userData && !allowedRoles.includes(userData.role)) {
    // Redirect based on role if they accessed wrong dashboard
    if (userData.role === 'admin') return <Navigate to="/dashboard/admin" replace />;
    if (userData.role === 'seller') return <Navigate to="/dashboard/seller" replace />;
    if (userData.role === 'affiliate') return <Navigate to="/dashboard/affiliate" replace />;
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};
