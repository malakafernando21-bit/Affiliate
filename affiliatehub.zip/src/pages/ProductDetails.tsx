import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router';
import { doc, getDoc, addDoc, collection } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';
import { Loader2, ShieldCheck, Truck, RotateCcw } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  sellerId: string;
}

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const affiliateId = searchParams.get('ref');
  
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  const [hasTrackedClick, setHasTrackedClick] = useState(false);

  useEffect(() => {
    if (id) {
      fetchProduct();
    }
  }, [id]);

  useEffect(() => {
    if (product && affiliateId && !hasTrackedClick) {
      trackClick();
    }
  }, [product, affiliateId]);

  const fetchProduct = async () => {
    try {
      const docRef = doc(db, 'products', id!);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        setProduct({ id: docSnap.id, ...docSnap.data() } as Product);
      } else {
        toast.error('Product not found');
      }
    } catch (error) {
      console.error(error);
      toast.error('Failed to load product');
    } finally {
      setLoading(false);
    }
  };

  const trackClick = async () => {
    try {
      // Create click record
      await addDoc(collection(db, 'clicks'), {
        productId: id,
        affiliateId,
        timestamp: new Date().toISOString()
      });
      setHasTrackedClick(true);
      console.log('Affiliate click tracked successfully.');
    } catch (error) {
      // Click tracking failing shouldn't break the user experience
      console.error("Failed to track click:", error);
    }
  };

  const handlePurchase = async () => {
    if (!product) return;
    setPurchasing(true);
    
    // Simulate payment processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // If there is an affiliate ID, simulate adding a commission
    if (affiliateId) {
      try {
        await addDoc(collection(db, 'commissions'), {
          productId: id,
          affiliateId,
          amount: product.price * 0.1, // 10% commission
          status: 'pending',
          timestamp: new Date().toISOString()
        });
        toast.success("Purchase successful! Affiliate commission recorded.");
      } catch (error) {
        console.error("Failed to record commission", error);
        toast.success("Purchase successful!");
      }
    } else {
      toast.success("Purchase successful!");
    }
    
    setPurchasing(false);
  };

  if (loading) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <Loader2 className="animate-spin text-indigo-500" size={40} />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <div className="bg-white p-8 rounded-3xl shadow-sm text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Product not found</h2>
          <p className="text-gray-500">The product you are looking for does not exist or has been removed.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 w-full flex-grow">
      <div className="bg-white rounded-3xl shadow-xl shadow-gray-200/50 overflow-hidden border border-gray-100 flex flex-col md:flex-row">
        
        {/* Product Image */}
        <div className="md:w-1/2 bg-gray-50 relative min-h-[300px] md:min-h-[500px]">
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        
        {/* Product Details */}
        <div className="md:w-1/2 p-8 md:p-12 flex flex-col">
          {affiliateId && (
            <div className="mb-6 inline-flex items-center gap-2 bg-purple-50 text-purple-700 px-3 py-1.5 rounded-lg text-sm font-medium border border-purple-100 w-fit">
              <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></span>
              You were referred by an affiliate
            </div>
          )}
          
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{product.name}</h1>
          <div className="text-3xl font-extrabold text-indigo-600 mb-6">${product.price.toFixed(2)}</div>
          
          <div className="prose prose-gray mb-8">
            <p className="text-gray-600 leading-relaxed text-lg">{product.description}</p>
          </div>
          
          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
              <ShieldCheck className="text-green-500" size={20} />
              Secure 1-Click Checkout
            </div>
            <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
              <Truck className="text-blue-500" size={20} />
              Instant Digital Delivery
            </div>
            <div className="flex items-center gap-3 text-sm text-gray-600 font-medium">
              <RotateCcw className="text-orange-500" size={20} />
              30-Day Money-Back Guarantee
            </div>
          </div>
          
          <div className="mt-auto">
            <button 
              onClick={handlePurchase}
              disabled={purchasing}
              className="w-full py-4 bg-gray-900 hover:bg-gray-800 text-white rounded-2xl font-bold text-lg shadow-lg shadow-gray-900/20 transition-all hover:scale-[1.02] disabled:opacity-75 disabled:hover:scale-100 flex justify-center items-center gap-3"
            >
              {purchasing ? (
                <>
                  <Loader2 className="animate-spin" size={24} />
                  Processing...
                </>
              ) : (
                'Buy Now'
              )}
            </button>
            <p className="text-center text-xs text-gray-400 mt-4">
              This is a simulated checkout. No real charges will be made.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
