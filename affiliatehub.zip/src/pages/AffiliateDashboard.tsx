import React, { useState, useEffect } from 'react';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { useAuth } from '../lib/auth';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';
import { Copy, Loader2, Link as LinkIcon, DollarSign, TrendingUp, Search } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  sellerId: string;
}

export default function AffiliateDashboard() {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [stats, setStats] = useState({ clicks: 0, pending: 0, paid: 0 });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchProducts();
    if (user) {
      fetchStats();
    }
  }, [user]);

  const fetchStats = async () => {
    if (!auth.currentUser) return;
    try {
      const [clicksSnap, commsSnap] = await Promise.all([
        getDocs(query(collection(db, 'clicks'), where('affiliateId', '==', auth.currentUser.uid))),
        getDocs(query(collection(db, 'commissions'), where('affiliateId', '==', auth.currentUser.uid)))
      ]);

      let pending = 0;
      let paid = 0;
      commsSnap.forEach(doc => {
        const data = doc.data();
        if (data.status === 'pending') pending += data.amount || 0;
        if (data.status === 'paid') paid += data.amount || 0;
      });

      setStats({
        clicks: clicksSnap.size,
        pending,
        paid
      });
    } catch (e) {
      console.error(e);
    }
  };

  const fetchProducts = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'products'));
      const fetchedProducts: Product[] = [];
      querySnapshot.forEach((doc) => {
        fetchedProducts.push({ id: doc.id, ...doc.data() } as Product);
      });
      setProducts(fetchedProducts);
    } catch (error: any) {
      toast.error('Failed to load products');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const getAffiliateLink = (productId: string) => {
    if (!user) return '';
    const baseUrl = window.location.origin;
    return `${baseUrl}/product/${productId}?ref=${user.uid}`;
  };

  const copyToClipboard = (productId: string) => {
    const link = getAffiliateLink(productId);
    navigator.clipboard.writeText(link);
    toast.success('Affiliate link copied to clipboard!');
  };

  const filteredProducts = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900">Affiliate Center</h1>
        <p className="text-gray-500 mt-1">Find products to promote and track your earnings.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
            <LinkIcon size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Clicks</p>
            <p className="text-2xl font-bold text-gray-900">{stats.clicks}</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
            <DollarSign size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Unpaid Earnings</p>
            <p className="text-2xl font-bold text-gray-900">${stats.pending.toFixed(2)}</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center">
            <TrendingUp size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Paid Out</p>
            <p className="text-2xl font-bold text-gray-900">${stats.paid.toFixed(2)}</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-xl font-bold text-gray-900">Available Products</h2>
        <div className="relative w-full sm:w-64">
          <input 
            type="text" 
            placeholder="Search products..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all"
          />
          <Search size={18} className="absolute left-3 top-2.5 text-gray-400" />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="animate-spin text-indigo-500" size={32} />
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="bg-white rounded-3xl border border-gray-100 p-12 text-center shadow-sm">
          <h3 className="text-xl font-bold text-gray-900 mb-2">No products found</h3>
          <p className="text-gray-500">There are currently no products available to promote.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col"
            >
              <div className="h-48 w-full bg-gray-100 overflow-hidden">
                <img 
                  src={product.imageUrl} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-5 flex-grow flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-lg text-gray-900 line-clamp-1">{product.name}</h3>
                  <span className="font-semibold text-gray-900">${product.price.toFixed(2)}</span>
                </div>
                <p className="text-gray-500 text-sm line-clamp-2 mb-4 flex-grow">{product.description}</p>
                
                <div className="mt-auto">
                  <div className="text-xs text-green-600 font-medium mb-2 bg-green-50 w-fit px-2 py-1 rounded inline-block">
                    Earn 10% commission ($\{(product.price * 0.1).toFixed(2)})
                  </div>
                  <button 
                    onClick={() => copyToClipboard(product.id)}
                    className="w-full py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-medium rounded-xl flex items-center justify-center gap-2 transition-colors border border-indigo-100"
                  >
                    <Copy size={16} />
                    Copy Affiliate Link
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
