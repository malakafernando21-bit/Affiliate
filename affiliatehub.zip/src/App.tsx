import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './lib/auth';
import { ProtectedRoute } from './components/ProtectedRoute';

// Pages
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import SellerDashboard from './pages/SellerDashboard';
import AffiliateDashboard from './pages/AffiliateDashboard';
import AdminDashboard from './pages/AdminDashboard';
import ProductDetails from './pages/ProductDetails';
import Navbar from './components/Navbar';

const DashboardRedirect = () => {
  const { userData, loading } = useAuth();
  
  if (loading) return null;
  
  if (userData?.role === 'seller') return <Navigate to="/dashboard/seller" replace />;
  if (userData?.role === 'affiliate') return <Navigate to="/dashboard/affiliate" replace />;
  if (userData?.role === 'admin') return <Navigate to="/dashboard/admin" replace />;
  
  return <Navigate to="/login" replace />;
};

function AppRoutes() {
  return (
    <div className="min-h-screen bg-gray-50/50 flex flex-col font-sans text-gray-900">
      <Navbar />
      <main className="flex-grow flex flex-col">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/product/:id" element={<ProductDetails />} />
          
          {/* Protected Routes */}
          <Route element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<DashboardRedirect />} />
            
            <Route element={<ProtectedRoute allowedRoles={['seller']} />}>
              <Route path="/dashboard/seller" element={<SellerDashboard />} />
            </Route>
            
            <Route element={<ProtectedRoute allowedRoles={['affiliate']} />}>
              <Route path="/dashboard/affiliate" element={<AffiliateDashboard />} />
            </Route>
            
            <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
              <Route path="/dashboard/admin" element={<AdminDashboard />} />
            </Route>
          </Route>
        </Routes>
      </main>
      <Toaster position="top-right" 
        toastOptions={{
          style: {
            background: '#333',
            color: '#fff',
            borderRadius: '12px',
          }
        }} 
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
